import { Component } from '@angular/core';
import { PokemonService } from './services/pokemon.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  pokemons: any[] = [];
  url_next: string = '';
  url_previous: string = '';
  atrasDeshabilitado: boolean = true;
  adelanteDeshabilitado: boolean = false;
  nombre: string = "";
  pokemon: any;

  constructor(private pokemonService: PokemonService){
    
    // Esto no se puede hacer
    // this.pokemons = pokemonService.getAll();

    // Me subscribo al observable para estar atenta de recibir los datos
    this.pokemonService.getAll().subscribe( datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      this.url_next = datos.next;
    });
  }

  buscar(){
    this.pokemonService.buscarPokemon(this.nombre).subscribe(item => {
      console.log(item);
      this.pokemon = item;
    });
  }

  atras(){
    this.pokemonService.emitirPeticion(this.url_previous).subscribe( datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      if (datos.next != null){
        this.adelanteDeshabilitado = false;  
      }
      this.url_next = datos.next; 
      if (datos.previous == null){
        this.atrasDeshabilitado = true;
      } else {
        this.url_previous = datos.previous;
      }
    });
  }

  adelante(){
    this.pokemonService.emitirPeticion(this.url_next).subscribe( datos => {
      //console.log(datos);
      this.pokemons = datos.results;
      if (datos.next == null){
        this.adelanteDeshabilitado = true;
      } else {
        this.url_next = datos.next;
      }
      this.url_previous = datos.previous;
      this.atrasDeshabilitado = false;
    });
  }

}
