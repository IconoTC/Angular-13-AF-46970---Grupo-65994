import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  texto: string = "Bienvenidos al curso de Angular";

  /*
  persona: Object = {
    "nombre":"Pepito", "apellido":"Perez", "edad":36,
    "telefonos":{"tel1":911234567, "tel2": 616987654}
  };*/
  persona: Object = {
    nombre:"Pepito", apellido:"Perez", edad:36,
    telefonos:{tel1:911234567, tel2: 616987654}
  };

  numero: number = 776543378.55732678998798;
  porcentaje: number = 0.5378765;

  // Funciona de cualquiera de las 3 formas
  fecha: Date = new Date();   // Fecha del sistema
  //fecha: Date = new Date('7/25/2024');    // mes/dia/año
  //fecha: string = '7/25/2024';
}
