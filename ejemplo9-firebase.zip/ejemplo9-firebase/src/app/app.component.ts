import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  amigos: any[] = [];
  id: string = '';
  contacto: any;
  modificar: boolean = false;

  amigoForm = new FormGroup({
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    this.agendaService.getAll().subscribe(datos => {
      this.amigos = [];
      datos.forEach(item => {
        this.amigos.push(item.payload.doc.data());
      });
    });
  }

  alta(){
    this.agendaService.nuevoAmigo(this.amigoForm.value)
      .then(() => {
        // Limpiar el formulario
        this.amigoForm.reset();
      })
      .catch((error) => {
        console.log(error)
      });
  }

  buscarAmigo(){
    this.agendaService.buscarPorId(this.id).subscribe( item => {
      this.contacto = item.payload.data();
    });
  }

  editar(){
    this.amigoForm.setValue(this.contacto);
    this.modificar = true;
  }

  eliminar(): void{
    this.agendaService.borrarAmigo(this.id)
      .then(() => {
        alert("Contacto eliminado");
        this.id = '';
      })
      .catch((error) => {
        console.log(error)
      }); 
  }

  modificarContacto(){
    this.agendaService.modificarAmigo(this.id, this.amigoForm.value)
      .then(() => {
        this.amigoForm.reset();
        this.modificar = false;
        this.id = '';
      })
      .catch((error) => {
        console.log(error)
      }); 
  }
}

