import { Action, AngularFirestore, DocumentChangeAction, DocumentReference, DocumentSnapshot } from '@angular/fire/firestore';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private db = "/agenda";

  constructor(private angularFirestore: AngularFirestore){}

  getAll(): Observable<DocumentChangeAction<unknown>[]>     {
    return this.angularFirestore.collection(this.db).snapshotChanges();
  }

  buscarPorId(id: string): Observable<Action<DocumentSnapshot<unknown>>>{
    return this.angularFirestore.collection(this.db).doc(id).snapshotChanges();
  }

  /*
  buscarPorNombre(nombre: string): any[] {
    return this.amigos.filter(item => item.nombre.includes(nombre));
  }*/

  nuevoAmigo(nuevo: any): Promise<DocumentReference<unknown>>  {
    return this.angularFirestore.collection(this.db).add(nuevo);
  }

  borrarAmigo(id: string): Promise<void>{
    return this.angularFirestore.collection(this.db).doc(id).delete();
  }

  modificarAmigo(id:string, amigo: any): Promise<void>{
    return this.angularFirestore.collection(this.db).doc(id).set(amigo);
  }
}

