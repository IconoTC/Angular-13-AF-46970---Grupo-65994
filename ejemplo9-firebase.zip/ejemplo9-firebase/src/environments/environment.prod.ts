export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: "AIzaSyA0ZM6YKKWk7605_k3i_c_-lay8HV5UzJQ",
    authDomain: "angular-5-anabel.firebaseapp.com",
    projectId: "angular-5-anabel",
    storageBucket: "angular-5-anabel.appspot.com",
    messagingSenderId: "794014030430",
    appId: "1:794014030430:web:67e9e1046862f67b92f2cf"
  }
};
