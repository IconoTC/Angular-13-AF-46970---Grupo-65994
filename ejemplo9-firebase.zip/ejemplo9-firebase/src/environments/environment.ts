// This file can be replaced during build by using the `fileReplacements` array.
// `ng build` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
  firebaseConfig: {
    apiKey: "AIzaSyA0ZM6YKKWk7605_k3i_c_-lay8HV5UzJQ",
    authDomain: "angular-5-anabel.firebaseapp.com",
    projectId: "angular-5-anabel",
    storageBucket: "angular-5-anabel.appspot.com",
    messagingSenderId: "794014030430",
    appId: "1:794014030430:web:67e9e1046862f67b92f2cf"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/plugins/zone-error';  // Included with Angular CLI.
