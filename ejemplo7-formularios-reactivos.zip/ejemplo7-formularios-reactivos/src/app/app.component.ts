import { Component } from '@angular/core';
import { AgendaService } from './services/agenda.service';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  
  amigos: any[] = [];
  nombre: string = '';
  amigosEncontrados: any[] = [];
  modificar: boolean = false;

  amigoForm = new FormGroup({
    id: new FormControl(0, [Validators.required, Validators.min(1)]),
    nombre: new FormControl('', [Validators.required, Validators.minLength(3)]),
    telefono: new FormControl('', [Validators.required, Validators.pattern('[6-7]{1}[0-9]{8}')])
  });

  constructor(private agendaService: AgendaService){
    this.amigos = agendaService.getAll();
  }

  alta(){
    this.agendaService.nuevoAmigo(this.amigoForm.value);

    // Limpiar el formulario
    this.amigoForm.reset();
  }

  buscarAmigos(){
    this.amigosEncontrados = this.agendaService.buscarPorNombre(this.nombre);
  }

  eliminar(id: number): void{
    this.agendaService.borrarAmigo(id);
    this.amigosEncontrados = [];
    this.nombre = '';
  }

  editar(amigo: any){
    this.amigoForm.setValue(amigo);
    this.modificar = true;
  }

  modificarContacto(){
    this.agendaService.modificarAmigo(this.amigoForm.value);
    this.amigoForm.reset();
    this.modificar = false;
    this.amigosEncontrados = [];
    this.nombre = '';
  }
}
