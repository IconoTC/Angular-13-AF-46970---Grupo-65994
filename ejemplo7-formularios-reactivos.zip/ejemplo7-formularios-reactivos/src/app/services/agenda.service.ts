import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class AgendaService {

  private amigos: any[] = [
    {id: 1, nombre: "Juan", telefono: "616111111"},
    {id: 2, nombre: "Maria", telefono: "616222222"}
  ];

  getAll(): any[]{
    return this.amigos;
  }

  buscarPorId(id: number): any{
    return this.amigos.find(item => item.id == id);
  }

  buscarPorNombre(nombre: string): any[] {
    return this.amigos.filter(item => item.nombre.includes(nombre));
  }

  nuevoAmigo(nuevo: any): void{
    this.amigos.push(nuevo);
  }

  borrarAmigo(id: number): void{
    // Buscar el indice del elemento a eliminar
    let indice = this.amigos.findIndex(item => item.id == id);

    // Borramos ese indice de la lista
    this.amigos.splice(indice, 1);
  }

  modificarAmigo(amigo: any): void{
    this.amigos.forEach(item => {
      if (item.id == amigo.id){
        item.nombre = amigo.nombre;
        item.telefono = amigo.telefono;
      }
    });
  }
}

